import os

class Config:
    SECRET_KEY = '123-4567-890'
    # MySQL
    MYSQL_USER = 'root'
    MYSQL_PASSWORD = 'passwd'
    MYSQL_HOST = 'localhost'
    MYSQL_DB = 'music_school'
    SQLALCHEMY_DATABASE_URI = f'mysql+pymysql://{MYSQL_USER}:{MYSQL_PASSWORD}@{MYSQL_HOST}/{MYSQL_DB}'
    SQLALCHEMY_TRACK_MODIFICATIONS = False