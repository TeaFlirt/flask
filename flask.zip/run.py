from app import create_app

app = create_app()

if __name__ == '__main__':
    # debug=True автоматически перезагружает сервер при изменениях кода
    app.run(debug=True, host='0.0.0.0', port=5000)